@include('frontend/header')
 <!-- Start Login Area -->
        <section class="login-area currency-transfer-provider-with-background-color">
            <div class="container">
            <div class="row" style="padding-top: 120px;
    padding-bottom: 100px;">
        
                <div class="col-lg-6 col-md-12 p-4 m-auto">
                 
                       
                                <div class="login-form">


                            <div class="alert alert-success" role="alert">
  <h4 class="alert-heading">Congratulation!</h4>
  <p>Just to let you know, your account has been successfully activated. You can now log in to your account and access all features.</p>
  <hr>
  <a href="{{route('login')}}" class="btn btn-primary ">Log in</a>
</div>
                                
                          
                    </div>
                </div>
            </div>
            </div>
        </section>
        <!-- End Login Area -->



            <!-- Start Footer Area -->
@include('frontend/footer')