   @include('frontend/header')
       <!-- Start Page Title Area -->
        <div class="page-title-section">
            <div class="container">
                <div class="page-title-text">
                    <h2>Terms & Conditions</h2>
                    <p>Terms</p>

                    <ul>
                        <li><a href="index.html">Home</a></li>
                        <li>Terms & Conditions</li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- End Page Title Area --> 
   <!-- Start Choose Area -->
            <div class="ctp-choose-area pb-100">
                <div class="container">
                    <div class="row  m-0">
                       

                        <div class="col-md-12 p-0">
                            <div class="ctp-choose-content">
                                <h3>OUR Expressions FOR CARDS USE</h3>
                                <p>
                                    You can go through Your Record and Cards to how much the Accessible Equilibrium for Exchanges at Traders of the significant Card Plan. On the off chance that the Accessible Equilibrium is inadequate to pay for an Exchange, a few Shippers won't allow You to consolidate utilization of a Record or Cards with other installment techniques.
                                </p>
                                <p>
                                Exchanges might be limited via Card type, individual utilization examples and installment risk profiles. For against illegal tax avoidance and hostile to extortion reasons We save Our privileges to change specific installment limitations (counting from those in the Expenses and Cutoff points Sheet) without notice and to the degree expected to meet Guidelines.</p>

                                <div class="choose-inner-card">
                                    <h4>
                                        <div class="icon">
                                            <i class="fa-solid fa-check"></i>
                                        </div>
                                       Misfortune OR Burglary OF Safety Data OR ANY Actual CARD
                                    </h4>
                                    <p>
                                       On the off chance that You have applied for and been conceded an actual Card related with Your Record it can (dependent upon the Backer's expressions) be utilized to cause cash withdrawals from ATMs and banks who to consent to offer this support (dependent upon any most extreme set by the significant ATM administrator or bank).
                                        </p>
                                        <p>
                                            The worth of every Exchange and how much any Charges will be deducted from the Accessible Equilibrium. We won't send You a paper proclamation with respect to Your Record and Exchanges. You can really look at Your Accessible Equilibrium and Exchange history whenever by signing for to You.
                                            
                                        </p>
                                        
                                        <p>
                                            To shield You and Us from misrepresentation, Vendors (and ATM administrators if pertinent) will look for Authorisation prior to handling any Exchange. Assuming they can't get an Authorisation, they will be unable to continue with Your Exchange. When an Exchange that has been started has been Approved it can't then be deserted or removed.
                                        </p>
                                </div>
                                <div class="choose-inner-card">
                                    <h4>
                                        <div class="icon">
                                            <i class="fa-solid fa-check"></i>
                                        </div>
                                        Money and Cards
                                    </h4>
                                    <p>
                                     Whenever empowered, You will have the choice to move your Accessible Equilibrium from Your Record or Cards to different Records or Cards. In the event that You train us to make an exchange from Your Record to another record, the mentioned sum will be charged from Your Record and credited to the record you have taught us to move your Accessible Equilibrium to. You might bring about a Record Move Expense for this exchange.
                                        </p>
                                        
                                      <p>
                                          
                                          In a couple of conditions, We or the Shipper might anticipate that You should have an Accessible Equilibrium in the overflow of the Exchange aggregate (for example, auto utilize associations might expect there to be a more vital Accessible Equilibrium on your Card than the assessment of their bill to think about any refueling charge).
                                      </p>  
                                        
                                        <p>
                                            In a couple of conditions, Shippers might require affirmation that Your Accessible Equilibrium will cover the Exchange aggregate and will then, at that point, begin hold to the assessment of the Exchange on the Accessible Equilibrium (for example dwelling reservations). In the event a Dealer puts a 'pre-approval' for You, You won't move toward this total until the point that the Exchange is done or released by the Vendor which might require as long as 30 days.
                                        </p>
                                        
                                        <p>
                                            A couple of Shippers may not recognize portions using Our Records or Cards. It is Your commitment to check with each Dealer what its game plan is. We recognize no gamble on the off chance that a Shipper declines to recognize portion using Our Administrations.
                                        </p>
                                        
                                </div>
                                <div class="choose-inner-card">
                                    <h4>
                                        <div class="icon">
                                            <i class="fa-solid fa-check"></i>
                                        </div>
                                        Refunds
                                    </h4>
                                    <p>
                                        
 <p>An Exchange will be viewed as unapproved in the event that You have not given Your assent for the Exchange to be made. Assuming You accept that an Exchange has been made without Your assent You ought to reach Us as per the bearings on Our site however before card conveyance.</p>

 <p> <p>After Purchase and Request Card Discount Not Acknowledged, On the grounds that After Request we will Issue Card From Bank.But Now and again assuming we feel Discount potential we will Think about regarding Discount.</p>

 <p>In the event that you are not happy with the result of Your case for a discount or the defense accommodated declining the discount You might present a grumbling to Us as per Our web-based objections strategy or contact the protests authority as portrayed on the site of the Backer.</p>
                                    </p>
                                </div>
                                <div class="choose-inner-card">
                                    <h4>
                                        <div class="icon">
                                            <i class="fa-solid fa-check"></i>
                                        </div>
                                        Condition of use
                                    </h4>
                                    <p>
                                        We might decline to acknowledge any utilization of the Installment Administrations or Entropay Administrations which could penetrate these agreements or then again assuming We have sensible reason for thinking that You or any outsider has committed or are wanting to commit extortion or some other unlawful or un-allowed utilization of the Installment Administrations or Entropay Administrations.</p>

<p>Your capacity to utilize or get to the Administrations may every so often be interfered, for instance assuming We want to complete support on our frameworks or sites. If it's not too much trouble, contact Our client administrations through Our site ('Client Administrations') to tell Us of any issues You are encountering utilizing Your Card or Record and We will try to determine any issue.</p>

<p>Whenever empowered, You will have the choice to move your Accessible Equilibrium from Your Record or Cards to different Records or Cards. In the event that You educate us to make an exchange from Your Record to another record, the mentioned sum will be charged from Your Record and credited to the record you have trained us to move your Accessible Equilibrium to. You might bring about a Record Move Charge for this exchange.</p>

<p>In a couple of conditions We or the Trader might anticipate that You should have an Accessible Equilibrium in overflow of the Exchange total (for example, auto utilize associations might expect there to be a more significant Accessible Equilibrium on your Card than the assessment of their bill to think about any refueling charge).</p>

<p>In a couple of conditions Shippers might require affirmation that Your Accessible Equilibrium will cover the Exchange aggregate and will then, at that point, begin a hold to the assessment of the Exchange on the Accessible Equilibrium (for example dwelling reservations). In the event a Vendor puts a 'pre-authorisation' for You, You won't move toward this total until the point that the Exchange is done or released by the Trader which might require as long as 30 days.</p>

<p>A couple of Shippers may not recognize portion using Our Records or Cards. It is Your commitment to check with each Vendor what it's plan is. We recognize no gamble in the event that a Vendor declines to recognize portion using Our Administrations.</p>
                                    </p>
                                </div>
                                <div class="choose-inner-card">
                                    <h4>
                                        <div class="icon">
                                            <i class="fa-solid fa-check"></i>
                                        </div>
                                        Use of our account, global bank and cards
                                    </h4>
                                    <p>
                                        Exchanges might be limited via Card type, individual use examples, and installment risk profiles. For hostile to tax evasion and against extortion reasons We hold Our freedoms to change specific installment limitations (counting from those in the Expenses and Cutoff points Sheet) without notice and to the degree expected to meet Guidelines.

<p>You can go through Your Record and Cards to how much the Accessible Equilibrium for Exchanges at Shippers of the important Card Plan. In the event that the Accessible Equilibrium is deficient to pay for an Exchange, a few Traders won't allow You to consolidate the utilization of a Record or Cards with other installment strategies.</p>
                                    </p>
                                </div>
                                <div class="choose-inner-card">
                                    <h4>
                                        <div class="icon">
                                            <i class="fa-solid fa-check"></i>
                                        </div>
                                        Our Client's data Safety & protection
                                    </h4>
                                    
                                    <p>
                                        
                                        <p>We hold your own information for such period expected to meet our commitments under relevant regulations or guidelines and, to the degree not restricted under pertinent regulation, such extra period as per our interior arrangements and strategies for motivations behind avoidance of false exercises, risk the board and security.</p>

<p>All satisfied gave on our sites according to our administrations etc., including connections to different sites is accommodated data purposes just and doesn't comprise exhortation, suggestion or backing of such happy or site. Payowire bends over backward to give valid and precise substance on its sites. In any case, we gives no guarantee, express or suggested, of the precision, fulfillment, idealness, or pertinence of such happy. we acknowledges no liability regarding and avoids all risk regarding data gave on the our sites, including however not restricted to any responsibility for mistakes, errors or exclusions.</p>

<p>All data you give to us is put away on our solid servers or our outsider cloud specialist co-ops. Any installment exchanges will be encoded utilizing SSL innovation. Where we have given you (or where you have picked) a secret phrase which empowers you to get to specific pieces of our site, you are liable for keeping this secret word classified. We ask you not to impart a secret phrase to anybody.</p>

<p>Tragically, the transmission of data through the web isn't totally secure. Despite the fact that we will give our all to safeguard your own information, we can't ensure the security of your information communicated to our sites; any transmission is in spite of the obvious danger. Whenever we have accepted your data, we will utilize severe techniques and security highlights to attempt to forestall un-approved admittance.</p>
                                    </p>
                                </div>
                            </div>
                            </div>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Choose Area -->

      
      
        
        <!-- Start Footer Area -->
     <!-- Start Footer Area -->
      @include('frontend/footer')