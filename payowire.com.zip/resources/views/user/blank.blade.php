@include('user/header')
@include('user/sidebar')
<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
			

            

            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->





		
@include('user/footer')		