  <div class="mb-3 mb-0 text-center col-md-6 m-auto">

                                             <?php if(session('terror')): ?>

                                             <script>
                                                    toastr.error("<?php echo e(session('terror')); ?>", "Error!", {
                    positionClass: "toast-top-right",
                    timeOut: 5e3,
                    closeButton: !0,
                    debug: !1,
                    newestOnTop: !0,
                    progressBar: !0,
                    preventDuplicates: !0,
                    onclick: null,
                    showDuration: "300",
                    hideDuration: "1000",
                    extendedTimeOut: "1000",
                    showEasing: "swing",
                    hideEasing: "linear",
                    showMethod: "fadeIn",
                    hideMethod: "fadeOut",
                    tapToDismiss: !1
                });

                                             </script>

                                    

                                            <?php elseif(session('tsuccess')): ?>

                                            <script>
                                                       toastr.success("<?php echo e(session('tsuccess')); ?>", "Success!", {
                    timeOut: 5e3,
                    closeButton: !0,
                    debug: !1,
                    newestOnTop: !0,
                    progressBar: !0,
                    positionClass: "toast-top-right",
                    preventDuplicates: !0,
                    onclick: null,
                    showDuration: "300",
                    hideDuration: "1000",
                    extendedTimeOut: "1000",
                    showEasing: "swing",
                    hideEasing: "linear",
                    showMethod: "fadeIn",
                    hideMethod: "fadeOut",
                    tapToDismiss: !1
                });
            
                                            </script>

                                                     <?php endif; ?>

                                    </div><?php /**PATH C:\Users\User\Desktop\PEZON BHAI NEW\payowire.com\resources\views/helper/header_toast.blade.php ENDPATH**/ ?>