<div class="mb-3 mb-0 text-center col-md-6 m-auto">

                                             <?php if(session('error')): ?>

                                             <div class="alert alert-danger alert-dismissible fade show">
                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="btn-close">
                                    </button>
                                    <strong>Error!</strong> <?php echo e(session('error')); ?>

                                </div>
                                

                                            <?php elseif(session('success')): ?>

                                            <div class="alert alert-success alert-dismissible fade show">
                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="btn-close">
                                    </button>
                                    <strong>Success!</strong> <?php echo e(session('success')); ?>

                                </div>

                                                     <?php endif; ?>

                                    </div><?php /**PATH C:\Users\User\Desktop\PEZON BHAI NEW\payowire.com\resources\views/helper/header_notify.blade.php ENDPATH**/ ?>