           <script  type="text/javascript">


$('#<?php echo e($parent); ?>').on('click', '#<?php echo e($click); ?>', function(){

    $("#<?php echo e($msg); ?>").html('<div class="spinner-border text-primary" role="status"></div>');
    
$.post($("#<?php echo e($formid); ?>").attr("action"),$("#<?php echo e($formid); ?> :input").serializeArray(),function(info){
  
    
    $("#<?php echo e($msg); ?>").html(info);
    $("#<?php echo e($click); ?>").attr("disabled", false);
    //clearInput();
  })
  .fail( function(xhr, textStatus, errorThrown) {

      $("#<?php echo e($msg); ?>").html("");

      $("#<?php echo e($click); ?>").attr("disabled", false);

      var count = 0;

       
           $.each(xhr.responseJSON.errors, function (key, value) {

                var error_msg='<li class="reponse_item">'+value+'</li>';

                if(value!="")
            $("#<?php echo e($msg); ?>").html($("#<?php echo e($msg); ?>").html()+error_msg);

                count++;



                    });

           if($("#<?php echo e($msg); ?>").html() == "")

            $("#<?php echo e($msg); ?>").html('<div class="alert alert-danger alert-dismissible text-start" role="alert"><ul>Connection error! Please try again.</ul><button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>');
        else
            $("#<?php echo e($msg); ?>").html('<div class="alert alert-danger alert-dismissible text-start" role="alert"><ul>'+$("#<?php echo e($msg); ?>").html()+'</ul><button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>');

        if(count==1)
        {
            $('.reponse_item').removeClass('reponse_item');
            $('.text-start').addClass('text-center').removeClass('text-start');
        }
      


    });

});

$("#<?php echo e($formid); ?>").submit( function(){
    $("#<?php echo e($click); ?>").attr("disabled", true);
  return false;
});


  </script><?php /**PATH C:\Users\User\Desktop\PEZON BHAI NEW\payowire.com\resources\views/helper/elm_form_submit.blade.php ENDPATH**/ ?>