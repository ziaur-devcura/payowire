<?php echo $__env->make('user/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('user/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <!-- row -->
			<div class="container-fluid">


                        <div class="col-xl-12 col-xxl-12">
                        <div class="card">

                          
                            <div class="card-body  p-0">


                                <div class="d-flex flex-wrap align-items-center m-4">

                                <div class="me-auto">
                                    <h4 class="card-title mb-2">All Transactions</h4>
                                    <span class="fs-12">You can view all your transactions</span>
                                </div>

                                 <?php if(count($all_transaction)>0): ?>

                                <a href="javascript:void(0);" data-bs-toggle="modal" data-bs-target="#search_card_modal" class="btn btn-primary btn-rounded btn-md"><i class="flaticon-381-search-2"></i></a>
                                <?php endif; ?>

                            </div>

                               <?php if(count($all_transaction)>0): ?>

                           

                                    <div class="table-responsive">
                                        <table class="table table-responsive-md card-table transactions-table table-fit">

                                            <thead>

                                        <tr role="row">
   <th class="sorting" style="width: 14rem;">Transaction ID</th>
   <th class="sorting">Date Time</th>
   <th class="sorting">Amount</th>
   <th class="sorting">Type</th>

   <th class="sorting" style="width: 13rem;">Previous Balance</th>

   <th class="sorting" style="width: 13rem;">Current Balance</th>


   <th class="sorting">Status</th>


 </tr>
                                    </thead>

                                            <tbody>

                                              

                                         <?php $__currentLoopData = $all_transaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               
                              
                                                <tr>

                                                       <td class="text-nowrap">

                                                        <div class="d-flex flex-row bd-highlight align-items-center">
  <div class="bd-highlight">
       <?php echo $transaction->type_icon; ?>

  </div>
  <div class="bd-highlight">
      <h6 class="fs-16 font-w600 mb-0"><a href="javascript:void(0);" onclick="click_to_copy(this,'<?php echo e($transaction->id); ?>')" data-toggle="tooltip" data-placement="top" title="Click to copy" class="text-black">#<?php echo e($transaction->id); ?></a></h6>
  </div>
</div>

                                                        
                                                    </td>

                                                     <td class="text-nowrap">
                                                        <h6 class="fs-16 text-black font-w600 mb-0"><?php echo e($transaction->date); ?></h6>
                                                        <span class="fs-14"><?php echo e($transaction->time); ?></span>
                                                    </td>

                                                     <td><span class="fs-16 <?php echo e($transaction->amount_class); ?> font-w600"><?php echo e($transaction->next_type); ?><?php echo e($transaction->amount); ?></span></td>

                                                     <td>
                                                        <h6 class="fs-16 font-w600 mb-0"><?php echo $transaction->type; ?></h6>
                                                    </td>


                                                    <td><span class="fs-16 text-black font-w600">$<?php echo e($transaction->prev_balance); ?></span></td>


                                                   
                                                    <td><span class="fs-16 text-black font-w600">$<?php echo e($transaction->next_balance); ?></span></td>


                                                   
                                                    <td><?php echo $transaction->status; ?></td>
                                                </tr>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       
                                                
                                            </tbody>
                                        </table>
                                    </div>

                                      

                                        <?php else: ?>
                                        <hr class="mt-2">
                                        <center class="text-default"><p>You do not have any transaction yet.</p></center>
                                        <?php endif; ?>


                                           <div class="row mt-3">
                                            <div class="col-md-12 m-4">

                                                <?php echo e($all_transaction->links()); ?>

            
                                            </div>
                                        </div>
                                
                              
                            </div>
                        </div>
                    </div>
			

            

            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->





		
<?php echo $__env->make('user/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>		<?php /**PATH C:\Users\User\Desktop\PEZON BHAI NEW\payowire.com\resources\views/user/transaction.blade.php ENDPATH**/ ?>